#include "stdafx.h"
#include "ReactorSelectImpl.h"
#include "iostream"
using namespace std;

ReactorSelectImpl::ReactorSelectImpl()
{
}


ReactorSelectImpl::~ReactorSelectImpl()
{
}

int ReactorSelectImpl::run(int _cid, EventType _eType, int val1, int val2) {
	std::cout << "Start  ReactorSelectImpl " << std::endl;
	/*std::vector<int> aReadFds;
	std::vector<int> aWriteFds;
	std::vector<int> aExceptFds;*/

	int aResult = int(_eType);
	int ret = 0;
	switch (aResult) {

	case 0:
		std::cout << "ready to add" << std::endl;
		ret = val1 + val2;
		return ret;
		break;
	case 1:
		std::cout << "ready to sub" << std::endl;
		ret = val1 - val2;
		return abs(ret);
		break;
	case 2:
		std::cout << "Ready to mul" << std::endl;
		ret = val1*val2;
		return ret;
		break;
	case 3:
		std::cout << "Ready to div " << std::endl;
		if (val2 == 0)
		{
			cout << "divider should not be zero" << endl;
			return -1;
		}
		else {
			ret = val1 / val2;
			return ret;
		}
		break;
	default:
		std::cout << "Error " << std::endl;
		break;


	}
	return -1;
}
