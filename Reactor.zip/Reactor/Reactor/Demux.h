#ifndef __DEMUX_H__
#define __DEMUX_H__

#include "vector"
#include "EventType.h"
#include "InitiationDispatcher.h"

using namespace std;

class Demux {
private:
	std::vector<operation> clientInfo;
	InitiationDispatcher initDispatch;
public:
	Demux();
	~Demux();
	int demuxHandler(operation input_struct);
	bool addHandler(operation input_struct);
	void registerHandler(operation input_struct);
	int dispatchHandler(operation input_struct);
	void unregister(operation input_struct);
	//~Demux();
};
#endif