#include "stdafx.h"
#include "Demux.h"
#include <iostream>
//#include "stdafx.h"

using namespace std;

Demux::Demux() {
}

Demux::~Demux() {
	
}
bool Demux::addHandler(operation input_struct) {

	for (int i = 0; i<clientInfo.size(); ++i) {
		if (clientInfo[i].id == input_struct.id) {
			return false;
		}
	}
	clientInfo.push_back(input_struct);
	return true;
}



int Demux::demuxHandler(struct operation input_struct) {

	cout << "id : " << input_struct.id << " Event Type" << input_struct.type<<endl;
	if (addHandler(input_struct) == false) {
		cout << "client is already added" << endl;
	}
	registerHandler(input_struct);
	int ret=dispatchHandler(input_struct);
	return ret;
}

void Demux::registerHandler(struct operation input_struct) {

	if (initDispatch.RegisterHandlers(input_struct.id, input_struct.type)) {
		cout << "Client is already registered" << endl;
	}

	//call the register Initiate Dispatcher
}

int Demux::dispatchHandler(operation input_struct) {
	int ret = initDispatch.DipatchEvent(input_struct.id, input_struct.type, input_struct.data1, input_struct.data2);
	if (ret == -1) {
		cout << "Error in input" << endl;
	}
	return ret;
	//dispatch Handler
}

void Demux::unregister(operation input_struct) {
	initDispatch.UnRegisterHandlers(input_struct.id, input_struct.type);
}

