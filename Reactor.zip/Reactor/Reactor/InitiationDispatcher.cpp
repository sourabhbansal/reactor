#include "stdafx.h"
#include "InitiationDispatcher.h"
#include "iostream"
#include "ReactorSelectImpl.h"

using namespace std;

InitiationDispatcher::InitiationDispatcher()
{
	cout << "Constructor of InitiationDispatcher" << endl;
}


InitiationDispatcher::~InitiationDispatcher()
{
	cout << "Destructor of InitiationDispatcher" << endl;
}


bool InitiationDispatcher::RegisterHandlers(int client_Id, EventType event_type) {
	map<int, TypeHandlerMap>::iterator it = clientEventMap.find(client_Id);
	TypeHandlerMap type_hnd_map;
	type_hnd_map.type = event_type;
	type_hnd_map.hnd = eventHandler.GetHandler(event_type);

	if (it == clientEventMap.end()) {
		cout << "RegisterHandlers" << endl;
		clientEventMap.insert(pair<int, TypeHandlerMap>(client_Id, type_hnd_map));
	}
	else {
		cout << "Client ID is already Registered" << endl;
		return true;
	}
	return false;
}

void InitiationDispatcher::UnRegisterHandlers(int client_Id, EventType event_type) {
	cout << "UnRegisterHandlers" << endl;
	for (map<int, TypeHandlerMap>::iterator it = clientEventMap.begin(); it != clientEventMap.end(); ++it) {
		if (clientEventMap.find(client_Id)!= clientEventMap.end()) {
			clientEventMap.erase(it);
		}
	}
}


int InitiationDispatcher::DipatchEvent(int client_Id, EventType event_type, int val1, int val2) {
	//ReactorSelectImpl obj;
	int ret = handler.run(client_Id, event_type, val1, val2);
	
	/*for (map<int, TypeHandlerMap>::iterator it = clientEventMap.begin(); it != clientEventMap.end(); ++it) {
		if ( run(it->second client_Id, event_type,val1, val2 )()) {
			cout << "Handling Completed";
		}
	}*/
	return ret;
}