#include"EventType.h"

class EventHandler
{
public:
	EventHandler();
	~EventHandler();
	virtual bool HandleEvent();
	EventHandler* GetHandler(EventType type);
};


class SumHandler : public EventHandler
{
public :
	bool HandleEvent() {
		return 0;
	}
};

class DiffHandler : public EventHandler
{
	bool HandleEvent() {
		return 0;
	}
};

class MulHandler : public EventHandler
{
	bool HandleEvent() {
		return 0;
	}
};

class DivHandler : public EventHandler
{
	bool HandleEvent() {

	}
};