#pragma once
#include "EventHandler.h"
#include "Client.h"
#include <map>
#include "ReactorSelectImpl.h"
#include "EventType.h"


struct TypeHandlerMap{
	EventType type;
	EventHandler* hnd;
};


class InitiationDispatcher
{
public:
	InitiationDispatcher();
	~InitiationDispatcher();
	bool RegisterHandlers(int client_Id,  EventType event_type);
	void UnRegisterHandlers(int client_Id,  EventType event_type);
	
	int  DipatchEvent(int client_Id, EventType event_type, int val1, int val2);
	std::map < int, TypeHandlerMap> clientEventMap;
	EventHandler eventHandler;
	ReactorSelectImpl handler;
};

