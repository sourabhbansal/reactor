#pragma once

#include "EventType.h"



class Client
{
public:
	Client();
	~Client();
	int	client_request();
};







