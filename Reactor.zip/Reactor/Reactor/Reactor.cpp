// Reactor.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "iostream"
#include "Client.h"
#include<conio.h>
using namespace std;

int main()
{
	std::cout << "My Hackathon project" << endl;
	
	Client obj;
	obj.client_request();
	_getch();
    return 0;
}

