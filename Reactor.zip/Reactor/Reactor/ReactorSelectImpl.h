#pragma once
#include "EventType.h"

class ReactorSelectImpl
{
public:

	ReactorSelectImpl();
	~ReactorSelectImpl();
	int run(int cid, EventType eType, int val1, int val2);
};

