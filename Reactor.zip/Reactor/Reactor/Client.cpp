#include "stdafx.h"
#include "Client.h"
#include "Demux.h"
#include<iostream>

#define MAX 564365

using namespace std;
Client::Client()
{
}


Client::~Client()
{
}

int Client::client_request()
{
	struct operation opr;
	int i;
	for (i = 0; i < 10; i++)
	{
		opr.id = rand() % MAX;
		opr.type = (EventType)(opr.id % 4);
		opr.data1 = i + 1;
		opr.data2 = i + 3;
		Demux demux;

		int ret=demux.demuxHandler(opr);
		std::cout <<"id = "<<opr.id<<"data1 ="<<opr.data1 << "data2 =" <<opr.data2 <<"ret= "<<ret << std::endl;
	}
	return true;
}