#ifndef __EVENTTYPE_H__
#define __EVENTTYPE_H__


enum EventType
{
	ADD,
	SUB,
	MULTI,
	DIV
};

struct operation {
	int id;
	EventType type;
	int data1;
	int data2;
};

#endif